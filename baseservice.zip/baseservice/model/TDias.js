"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TDias = void 0;
var TDias;
(function (TDias) {
    TDias[TDias["LUNES"] = 0] = "LUNES";
    TDias[TDias["MARTES"] = 1] = "MARTES";
    TDias[TDias["MIERCOLES"] = 2] = "MIERCOLES";
    TDias[TDias["JUEVES"] = 3] = "JUEVES";
    TDias[TDias["VIERNES"] = 4] = "VIERNES";
    TDias[TDias["SABADO"] = 5] = "SABADO";
    TDias[TDias["DOMINGO"] = 6] = "DOMINGO";
})(TDias = exports.TDias || (exports.TDias = {}));
