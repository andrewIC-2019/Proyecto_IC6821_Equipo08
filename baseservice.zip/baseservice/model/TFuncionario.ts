export enum TFuncionario {
    ADMINISTRADOR,
    DOCENTE,
    INVESTIGADOR,
    VISITANTE,
}