export enum TVehiculo{
    PARTICULAR = 1,
    OFICIAL,
}