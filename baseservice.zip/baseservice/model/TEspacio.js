"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TEspacio = void 0;
var TEspacio;
(function (TEspacio) {
    TEspacio[TEspacio["COMUN"] = 0] = "COMUN";
    TEspacio[TEspacio["ESPECIAL"] = 1] = "ESPECIAL";
    TEspacio[TEspacio["JEFATURA"] = 2] = "JEFATURA";
    TEspacio[TEspacio["VISITANTE"] = 3] = "VISITANTE";
    TEspacio[TEspacio["OFICIAL"] = 4] = "OFICIAL";
})(TEspacio = exports.TEspacio || (exports.TEspacio = {}));
