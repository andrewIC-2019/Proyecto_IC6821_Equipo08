"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TPermisosUsuario = void 0;
var TPermisosUsuario;
(function (TPermisosUsuario) {
    TPermisosUsuario[TPermisosUsuario["CONSULTARESTACIONAMIENTOS"] = 0] = "CONSULTARESTACIONAMIENTOS";
    TPermisosUsuario[TPermisosUsuario["RESERVAR"] = 1] = "RESERVAR";
    TPermisosUsuario[TPermisosUsuario["EDITARUSUARIOS"] = 2] = "EDITARUSUARIOS";
    TPermisosUsuario[TPermisosUsuario["EDITARESTACIONAMIENTOS"] = 3] = "EDITARESTACIONAMIENTOS";
})(TPermisosUsuario = exports.TPermisosUsuario || (exports.TPermisosUsuario = {}));
