export enum TEspacio {
  COMUN,
  ESPECIAL,
  JEFATURA,
  VISITANTE,
  OFICIAL,
}
