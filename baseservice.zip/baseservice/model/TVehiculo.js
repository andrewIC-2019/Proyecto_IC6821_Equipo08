"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TVehiculo = void 0;
var TVehiculo;
(function (TVehiculo) {
    TVehiculo[TVehiculo["PARTICULAR"] = 1] = "PARTICULAR";
    TVehiculo[TVehiculo["OFICIAL"] = 2] = "OFICIAL";
})(TVehiculo = exports.TVehiculo || (exports.TVehiculo = {}));
