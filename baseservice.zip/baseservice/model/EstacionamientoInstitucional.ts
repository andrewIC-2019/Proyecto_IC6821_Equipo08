import { Estacionamiento } from "./Estacionamiento";

export class EstacionamientoInstitucinal extends Estacionamiento{
    
}