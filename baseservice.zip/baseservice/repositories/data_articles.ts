import { Logger } from '../common'

/*
VENGO DE LOS CONTROLADORES
*/

//aqui vendria lo de sql server
//lo basico para devolver datos
export class articles_data {
    private log: Logger;

    public constructor()
    {
    }

    public getAllArticles() : Promise<any>
    {
        return null;
    }

}