"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.articles_data = void 0;
/*
VENGO DE LOS CONTROLADORES
*/
//aqui vendria lo de sql server
//lo basico para devolver datos
var articles_data = /** @class */ (function () {
    function articles_data() {
    }
    articles_data.prototype.getAllArticles = function () {
        return null;
    };
    return articles_data;
}());
exports.articles_data = articles_data;
