"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ArticleController = void 0;
var articlescontroller_1 = require("./articlescontroller");
Object.defineProperty(exports, "ArticleController", { enumerable: true, get: function () { return articlescontroller_1.ArticleController; } });
