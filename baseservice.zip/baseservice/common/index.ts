//index para los imports de los objs en common, para que queden organizados,
// y no archivo por archivo
// (se recomienda)

//queda como publico lo que hay en el folder
export { Logger } from './logger/logger'
export { Article} from './library/article'