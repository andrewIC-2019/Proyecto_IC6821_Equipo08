"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Article = void 0;
//Objeto de uso común
var Article = /** @class */ (function () {
    function Article() {
    }
    return Article;
}());
exports.Article = Article;
