export interface DataSource {
  url: string;
  username: string;
  password: string;
  server: string;
}
