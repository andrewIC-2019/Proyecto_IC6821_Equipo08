"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DAOReservacionImpl = void 0;
var DAOReservacionImpl = /** @class */ (function () {
    function DAOReservacionImpl() {
    }
    DAOReservacionImpl.prototype.create = function (obj) {
        throw new Error("Method not implemented.");
    };
    DAOReservacionImpl.prototype.get = function (key) {
        throw new Error("Method not implemented.");
    };
    DAOReservacionImpl.prototype.getAll = function () {
        throw new Error("Method not implemented.");
    };
    DAOReservacionImpl.prototype.update = function (obj) {
        throw new Error("Method not implemented.");
    };
    return DAOReservacionImpl;
}());
exports.DAOReservacionImpl = DAOReservacionImpl;
