import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InformeOcupacionTotalXDepartamentoComponent } from './informe-ocupacion-total-xdepartamento.component';

describe('InformeOcupacionTotalXDepartamentoComponent', () => {
  let component: InformeOcupacionTotalXDepartamentoComponent;
  let fixture: ComponentFixture<InformeOcupacionTotalXDepartamentoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InformeOcupacionTotalXDepartamentoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InformeOcupacionTotalXDepartamentoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
