import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InformeOcupacionXTipoComponent } from './informe-ocupacion-xtipo.component';

describe('InformeOcupacionXTipoComponent', () => {
  let component: InformeOcupacionXTipoComponent;
  let fixture: ComponentFixture<InformeOcupacionXTipoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InformeOcupacionXTipoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InformeOcupacionXTipoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
