import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-modificarestacionamiento',
  templateUrl: './modificarestacionamiento.component.html',
  styleUrls: ['./modificarestacionamiento.component.css']
})
export class ModificarestacionamientoComponent implements OnInit {

  avisoCheck: string;
  form: FormGroup;
  jsonDatos: any;

  constructor(private dataservice: DataServiceService, private router: Router) { }

  ngOnInit(): void {

    console.log(this.dataservice.estacionamientoInfo);

    this.avisoCheck = '';
    this.form = new FormGroup({
      nombre: new FormControl(''),
      correo: new FormControl(''),
      telefono: new FormControl(''),
      direccionExacta: new FormControl(''),
      formaAccseo: new FormControl(''),
      descripcion: new FormControl(''),
      cantEspaciosEspeciales: new FormControl(0),
      cantEspaciosJefaturas: new FormControl(0),
      cantEspaciosVisitantes: new FormControl(0),
      cantEspacios: new FormControl(0),
      cantEspaciosOficiales: new FormControl(0),
      imageUrl: new FormControl(''),

      lunesA: new FormControl(''), lunesB: new FormControl(''),
      martesA: new FormControl(''), martesB: new FormControl(''),
      miercolesA: new FormControl(''), miercolesB: new FormControl(''),
      juevesA: new FormControl(''), juevesB: new FormControl(''),
      viernesA: new FormControl(''), viernesB: new FormControl(''),
      sabadoA: new FormControl(''), sabadoB: new FormControl(''),
      domingoA: new FormControl(''), domingoB: new FormControl(''),

      estacionamientoInstitucionalBox: new FormControl(false),
      estacionamientoSubcontratadoBox: new FormControl(false)
    });

    const respuesta = this.dataservice.pintarInformacionEstacionamiento(this.dataservice.estacionamientoInfo.estacionamientoId).subscribe(res =>{
      this.jsonDatos = res;
      console.log(this.jsonDatos);
      console.log(JSON.parse(this.jsonDatos[0])[0]);

      let nombre = JSON.parse(this.jsonDatos[0])[0].nombre;
      let correo = JSON.parse(this.jsonDatos[0])[0].correo;
      let telefono = JSON.parse(this.jsonDatos[0])[0].telefono;
      let direccionExacta = JSON.parse(this.jsonDatos[0])[0].direccionExacta;
      let formaAccseo = JSON.parse(this.jsonDatos[0])[0].formaAccseo;
      let descripcion = JSON.parse(this.jsonDatos[0])[0].descripcion;
      let cantEspacios = JSON.parse(this.jsonDatos[0])[0].cantEspacios;
      let cantEspaciosEspeciales = JSON.parse(this.jsonDatos[0])[0].cantEspaciosEspeciales;
      let cantEspaciosJefaturas = JSON.parse(this.jsonDatos[0])[0].cantEspaciosJefaturas;
      let cantEspaciosOficiales = JSON.parse(this.jsonDatos[0])[0].cantEspaciosOficiales;
      let cantEspaciosVisitantes = JSON.parse(this.jsonDatos[0])[0].cantEspaciosVisitantes;
      let imageUrl = JSON.parse(this.jsonDatos[0])[0].imageURL;

      let tipoEstacionamiento = JSON.parse(this.jsonDatos[0])[0].tipoEstacionamiento;

      if(tipoEstacionamiento == 1){
        this.form.get("estacionamientoInstitucionalBox")?.setValue(true);
        this.form.get("estacionamientoSubcontratadoBox")?.setValue(false);
      } else if (tipoEstacionamiento == 2){
        this.form.get("estacionamientoInstitucionalBox")?.setValue(false);
        this.form.get("estacionamientoSubcontratadoBox")?.setValue(true);
      }

      this.form.get("nombre")?.setValue(nombre);
      this.form.get("correo")?.setValue(correo);
      this.form.get("telefono")?.setValue(telefono);
      this.form.get("direccionExacta")?.setValue(direccionExacta);
      this.form.get("formaAccseo")?.setValue(formaAccseo);
      this.form.get("descripcion")?.setValue(descripcion);
      this.form.get("cantEspaciosEspeciales")?.setValue(cantEspaciosEspeciales);
      this.form.get("cantEspaciosJefaturas")?.setValue(cantEspaciosJefaturas);
      this.form.get("cantEspaciosOficiales")?.setValue(cantEspaciosOficiales);
      this.form.get("cantEspaciosVisitantes")?.setValue(cantEspaciosVisitantes);
      this.form.get("cantEspacios")?.setValue(cantEspacios);
      this.form.get("imageUrl")?.setValue(imageUrl);
      let contador = 0;
      for(let dia of (JSON.parse(this.jsonDatos[1]))){
        let diasemana = JSON.parse(this.jsonDatos[1])[contador].diaSemana;
        let horainicio = JSON.parse(this.jsonDatos[1])[contador].horaInicio;
        let horafinal = JSON.parse(this.jsonDatos[1])[contador].horaFinal;

        if(diasemana == 1){
          this.form.get("lunesA")?.setValue(horainicio);
          this.form.get("lunesB")?.setValue(horafinal);
        } 
        else if(diasemana == 2) {
          this.form.get("martesA")?.setValue(horainicio);
          this.form.get("martesB")?.setValue(horafinal);
        }
        else if(diasemana == 3) {
          this.form.get("miercolesA")?.setValue(horainicio);
          this.form.get("miercolesB")?.setValue(horafinal);
        }
        else if(diasemana == 4) {
          this.form.get("juevesA")?.setValue(horainicio);
          this.form.get("juevesB")?.setValue(horafinal);
        }
        else if(diasemana == 5) {
          this.form.get("viernesA")?.setValue(horainicio);
          this.form.get("viernesB")?.setValue(horafinal);
        }
        else if(diasemana == 6) {
          this.form.get("sabadoA")?.setValue(horainicio);
          this.form.get("sabadoB")?.setValue(horafinal);
        }
        else if(diasemana == 7) {
          this.form.get("domingoA")?.setValue(horainicio);
          this.form.get("domingoB")?.setValue(horafinal);
        }
        contador++;
      }



    })


  }

  submit(){
    /*Aquí se envia el JSON al dataservice para ser enviado al API*/
    if(this.verificarCheckbox() === 1){
      let jsonInputs = this.form.value;

      if(jsonInputs.estacionamientoInstitucionalBox == true){
        jsonInputs.tipoEstacionamiento = 1; 
      } else if(jsonInputs.estacionamientoSubcontratadoBox == true){
        jsonInputs.tipoEstacionamiento = 2;
      }

      jsonInputs.estacionamientoId = this.dataservice.estacionamientoInfo.estacionamientoId.toString();

      this.dataservice.modificarInformacionEstacionamiento(jsonInputs);
    }
  }

  verificarCheckbox() {
    if((this.form.value.estacionamientoInstitucionalBox === false && this.form.value.estacionamientoSubcontratadoBox === false) 
    || (this.form.value.estacionamientoInstitucionalBox === true && this.form.value.estacionamientoSubcontratadoBox === true)){
      this.avisoCheck = 'Marque solo una de las casillas'
      return 0;
    } else {
      this.avisoCheck = '';
      return 1;
    }
  }

  delete() {
    /*ELIMINO EL REGISTRO*/
    const id = this.dataservice.estacionamientoInfo.estacionamientoId.toString();
    let json = {estacionamientoId: id}
    this.dataservice.eliminarEstacionamiento(json);
  }

}
