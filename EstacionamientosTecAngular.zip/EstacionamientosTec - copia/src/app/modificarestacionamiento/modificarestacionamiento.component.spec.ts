import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModificarestacionamientoComponent } from './modificarestacionamiento.component';

describe('ModificarestacionamientoComponent', () => {
  let component: ModificarestacionamientoComponent;
  let fixture: ComponentFixture<ModificarestacionamientoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ModificarestacionamientoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ModificarestacionamientoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
