import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-registroestacionamiento',
  templateUrl: './registroestacionamiento.component.html',
  styleUrls: ['./registroestacionamiento.component.css']
})
export class RegistroestacionamientoComponent implements OnInit {

  avisoCheck: string;
  form: FormGroup;

  constructor(private dataservice: DataServiceService) { }

  ngOnInit(): void {
    this.avisoCheck = '';
    this.form = new FormGroup({
      nombre: new FormControl('', Validators.required),
      correo: new FormControl('', Validators.required),
      telefono: new FormControl('', Validators.required),
      direccionExacta: new FormControl('', Validators.required),
      formaAcceso: new FormControl('', Validators.required),
      descripcion: new FormControl('', Validators.required),
      identificacion: new FormControl('', Validators.required),
      cantEspaciosEspeciales: new FormControl(0, Validators.required),
      cantEspaciosJefaturas: new FormControl(0, Validators.required),
      cantEspaciosVisitantes: new FormControl(0, Validators.required),
      cantEspacios: new FormControl(0, Validators.required),
      cantEspaciosOficiales: new FormControl(0, Validators.required),
      imageUrl: new FormControl(''),
      lunesA: new FormControl(''), lunesB: new FormControl(''),
      martesA: new FormControl(''), martesB: new FormControl(''),
      miercolesA: new FormControl(''), miercolesB: new FormControl(''),
      juevesA: new FormControl(''), juevesB: new FormControl(''),
      viernesA: new FormControl(''), viernesB: new FormControl(''),
      sabadoA: new FormControl(''), sabadoB: new FormControl(''),
      domingoA: new FormControl(''), domingoB: new FormControl(''),
      tipoEstacionamiento: new FormControl('', Validators.required)
    });
  }

  submit(){
    /*Aquí se envia el JSON al dataservice para ser enviado al API*/
      let jsonInputs = this.form.value;

    if(jsonInputs.tipoEstacionamiento == 'institucional'){
      jsonInputs.esInstitucional = 1;
    } else if (jsonInputs.tipoEstacionamiento == 'subcontratado'){
      jsonInputs.esInstitucional = 0;
    } else {
      console.log('ningun tipo / no debería imprimir');
    }

      this.dataservice.registrarEstacionamiento(jsonInputs);
  }

  verificarCheckbox() {
    if((this.form.value.estacionamientoInstitucionalBox === false && this.form.value.estacionamientoSubcontratadoBox === false) 
    || (this.form.value.estacionamientoInstitucionalBox === true && this.form.value.estacionamientoSubcontratadoBox === true)){
      this.avisoCheck = 'Marque solo una de las casillas'
      return 0;
    } else {
      this.avisoCheck = '';
      return 1;
    }
  }

}
