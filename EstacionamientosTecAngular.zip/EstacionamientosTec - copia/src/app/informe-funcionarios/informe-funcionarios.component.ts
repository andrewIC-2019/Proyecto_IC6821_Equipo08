import { Component, OnInit } from '@angular/core';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-informe-funcionarios',
  templateUrl: './informe-funcionarios.component.html',
  styleUrls: ['./informe-funcionarios.component.css']
})
export class InformeFuncionariosComponent implements OnInit {

  dataFuncionarios: any;

  constructor(private dataservice: DataServiceService) { }

  ngOnInit(): void {
    this.funcionarios();
  }

  funcionarios(){
    const respuesta = this.dataservice.informeFuncionarios();
    respuesta.subscribe(res => {
      this.dataFuncionarios = res;
      console.log(this.dataFuncionarios);
    });
  }

  generateFuncionariosPDF(){
    let DATA: any = document.getElementById('informe-funcionarios');
    html2canvas(DATA).then((canvas) =>{
      let fileWidth = 208;
      let fileHeight = (canvas.height * fileWidth) / canvas.width;

      const FILEURI = canvas.toDataURL('image/png');
      let PDF = new jsPDF('p', 'mm', 'a4');
      let position = 10;
      PDF.addImage(FILEURI, 'PNG', 0, position, fileWidth, fileHeight);
      PDF.save('Reporte_Funcionarios.pdf');
    })
  }
  
}


