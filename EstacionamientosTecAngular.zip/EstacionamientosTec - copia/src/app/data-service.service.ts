import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, JsonpClientBackend } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class DataServiceService {

  connection: any;
  usuario: any;
  estacionamientoInfo: any;
  usuarioInfo: any;
  adminMenuFlag: string;
  index: string;

  exp: any;

  constructor(private http: HttpClient) {

    this.connection = {
      url: 'http://localhost:5000/api/'
    }

   }


  login(username: string, password: string){
    const params = new HttpParams().append('username', username).append('password', password);
    const jsonRespuesta = this.http.get(`${this.connection.url}/user/login`, {params});
    jsonRespuesta.subscribe(res => {
      this.usuario = res;
      this.usuario = this.usuario[0];
      console.log(this.usuario);
    });
    return jsonRespuesta;
  }

  inicio(){
    const jsonRespuesta = this.http.get(`${this.connection.url}/estacionamiento/inicio`);
    return jsonRespuesta;
  }

  infoEstacionamiento(id: string){
    const params = new HttpParams().append('estacionamientoId', id);
    const jsonRespuesta = this.http.get(`${this.connection.url}/estacionamiento/estacionamientoinfo`, {params});
    return jsonRespuesta;
  }

  infoUsuario(json: Object){

  }

  reservar(json: Object){

  }

  registrarFuncionario(json: Object){
    const jsonRespuesta = this.http.post(`${this.connection.url}/user/registrarUsuarioTotal`, json);
    return jsonRespuesta.subscribe();
  }

  pintarInformacionPropia(id: string){ 
    const params = new HttpParams().append('usuarioId', id); 
    const jsonRespuesta = this.http.get(`${this.connection.url}/user/pintarEditarUsuario`, {params});
    return jsonRespuesta;
  }

  pintarInformacionEstacionamiento(id: string){ 
    const params = new HttpParams().append('estacionamientoId', id); 
    const jsonRespuesta = this.http.get(`${this.connection.url}/estacionamiento/pintarEditarEstacionamiento`, {params});
    return jsonRespuesta;
  }

  modificarInformacionPropia(json: Object){
    const jsonRespuesta = this.http.post(`${this.connection.url}/user/guardarEditarUsuario`, json);
    return jsonRespuesta.subscribe();
  }

  modificarInformacionFuncionario(json: Object){
    const jsonRespuesta = this.http.post(`${this.connection.url}/user/guardarEditarUsuario`, json);
    return jsonRespuesta.subscribe();
  }

  modificarInformacionEstacionamiento(json: Object){ //TIRA ERROR EN API
    const jsonRespuesta = this.http.post(`${this.connection.url}/estacionamiento/guardarEditarEstacionamiento`, json);
    return jsonRespuesta.subscribe();
  }

  registrarEstacionamiento(json: Object){ 
    const jsonRespuesta = this.http.post(`${this.connection.url}/estacionamiento/registrarEstacionamientoTotal`, json);
    return jsonRespuesta.subscribe();
  }

  eliminarEstacionamiento(json: Object){
    const jsonRespuesta = this.http.post(`${this.connection.url}/estacionamiento/deshabilitarEstacionamiento`, json);
    return jsonRespuesta.subscribe();
  }

  eliminarFuncionario(json: Object){
    const jsonRespuesta = this.http.post(`${this.connection.url}/user/deshabilitarUsuario`, json);
    return jsonRespuesta.subscribe();
  }

  eliminarReserva(json: Object){

  }

  informeEstacionamientos(){
    const jsonRespuesta = this.http.get(`${this.connection.url}/user/informeEstacionamientos`);
    return jsonRespuesta;
  }

  informeFuncionarios(){
    const jsonRespuesta = this.http.get(`${this.connection.url}/user/informeFuncionarios`);
    return jsonRespuesta;
  }

  informeHoras(){
    const jsonRespuesta = this.http.get(`${this.connection.url}/user/franjasHorarias`);
    return jsonRespuesta;
  }

  informeFuncionario(id: string){ 
    const params = new HttpParams().append('identificacion', id); 
    const jsonRespuesta = this.http.get(`${this.connection.url}/user/consultaFuncionario`, {params});
    return jsonRespuesta;
  }

  getDepartamentos(){
    const jsonRespuesta = this.http.get(`${this.connection.url}/user/departamentos`);
    return jsonRespuesta;
  }

  getEstacionamientosAdmin(flag: string){
    const params = new HttpParams().append('subcontratados', flag);
    const jsonRespuesta = this.http.get(`${this.connection.url}/estacionamiento/estacionamientosTipoSubcontratados`, {params});
    return jsonRespuesta; 
  }
}
