import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EstacionamientosAdminComponent } from './estacionamientos-admin.component';

describe('EstacionamientosAdminComponent', () => {
  let component: EstacionamientosAdminComponent;
  let fixture: ComponentFixture<EstacionamientosAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EstacionamientosAdminComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EstacionamientosAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
