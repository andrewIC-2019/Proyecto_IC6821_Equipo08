import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InformeOcupacioTipoJefeComponent } from './informe-ocupacio-tipo-jefe.component';

describe('InformeOcupacioTipoJefeComponent', () => {
  let component: InformeOcupacioTipoJefeComponent;
  let fixture: ComponentFixture<InformeOcupacioTipoJefeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InformeOcupacioTipoJefeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InformeOcupacioTipoJefeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
