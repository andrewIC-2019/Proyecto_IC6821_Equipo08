import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InformeOcupacionXDepartamentoComponent } from './informe-ocupacion-xdepartamento.component';

describe('InformeOcupacionXDepartamentoComponent', () => {
  let component: InformeOcupacionXDepartamentoComponent;
  let fixture: ComponentFixture<InformeOcupacionXDepartamentoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InformeOcupacionXDepartamentoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InformeOcupacionXDepartamentoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
