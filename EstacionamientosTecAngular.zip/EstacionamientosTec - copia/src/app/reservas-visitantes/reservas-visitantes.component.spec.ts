import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReservasVisitantesComponent } from './reservas-visitantes.component';

describe('ReservasVisitantesComponent', () => {
  let component: ReservasVisitantesComponent;
  let fixture: ComponentFixture<ReservasVisitantesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReservasVisitantesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReservasVisitantesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
