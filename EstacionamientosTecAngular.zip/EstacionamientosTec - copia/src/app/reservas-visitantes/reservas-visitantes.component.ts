import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-reservas-visitantes',
  templateUrl: './reservas-visitantes.component.html',
  styleUrls: ['./reservas-visitantes.component.css']
})
export class ReservasVisitantesComponent implements OnInit {

 
  estacionamientoInfo: any;
  usuario: any;

  avisoCheck: string;
  form: FormGroup;
  mensaje1: any;
  mensaje2: any;

  constructor(private dataservice: DataServiceService, private router: Router) { }

  ngOnInit(): void {
    this.usuario = this.dataservice.usuario;
    this.cargaInfo();
    this.avisoCheck = '';

    this.form = new FormGroup({
      fecha: new FormControl('', Validators.required),
      horaInicio: new FormControl(''),
      horaFinal: new FormControl(''),
      espacioVisitante: new FormControl(true),
      espacioEspecial: new FormControl(false),
      vehiculo: new FormControl('', Validators.required),
      identificacion: new FormControl('', Validators.required),
      visitante: new FormControl(''),
      motivo: new FormControl(''),
      destino: new FormControl(''),
      entradaFlag: new FormControl(false),
      salidaFlag: new FormControl(false)
    });
  }

  async cargaInfo(){
    const estacionamientoId = this.dataservice.index;
    const respuesta = this.dataservice.infoEstacionamiento(estacionamientoId);
    respuesta.subscribe(res => {
      this.dataservice.estacionamientoInfo = res;
      this.estacionamientoInfo = this.dataservice.estacionamientoInfo;
      console.log(this.estacionamientoInfo);
    });
  }

  submit() {
    if(this.verificarCheck() === 1){
      this.avisoCheck = '';

      if(this.verificarHoras() === 1){
        this.mensaje1 = '';
        this.ajustarFechaHoras();
        let jsonInputs = this.form.value;

        if(this.verificarFlags() === 1){
          jsonInputs.tipoEspacioId = this.asignarTipoEspacio().toString();
          jsonInputs.estacionamientoId = this.dataservice.estacionamientoInfo[0].estacionamientoId.toString();
          jsonInputs.usuarioId = this.usuario.usuarioId.toString();
  
          jsonInputs.entrada = jsonInputs.horaInicio;
          jsonInputs.salida = jsonInputs.horaFinal;
  
          console.log(jsonInputs);

          if(jsonInputs.entradaFlag){
            //LLAMO AL API A REGISTRAR LA ENTRADA
            this.dataservice.reservarVisitasEntrada(jsonInputs);
            this.router.navigateByUrl('inicio');

          }else if(jsonInputs.salidaFlag){
            //LLAMO AL API A REGISTRAR LA SALIDA
            this.dataservice.reservarVisitasSalida(jsonInputs);
            this.router.navigateByUrl('inicio');
          }


        }else {
          this.setMensaje2();
        }

      } else {
        this.setMensaje1();
      }
    } else {
      this.avisoCheck = 'Seleccione únicamente un tipo de espacio';
    }
  }

  asignarTipoEspacio(){

    if(this.form.value.espacioEspecial === true){
      return 5
    }else if(this.form.value.espacioVisitante === true){
      return 3
    }
    return 0
  }

  ajustarFechaHoras(){
    this.form.value.horaInicio = this.form.value.fecha + " " + this.form.value.horaInicio;
    this.form.value.horaFinal = this.form.value.fecha + " " + this.form.value.horaFinal;
  }

  verificarCheck() {
    // let oficial = this.form.value.espacioVisitante;
    // let especial = this.form.value.espacioEspecial;
    // let jefatura = this.form.value.espacioJefatura;
    // let normal = this.form.value.espacioNormal;

    // let arrayBanderas = [especial, jefatura, normal, oficial];
    // let contador = 0;

    // for(let bandera of arrayBanderas) {
    //     if(bandera){
    //       contador++;
    //     }
    // }
    // if(contador === 1) {
    //   return 1;
    // } else {
    //   return 0;
    // }
    return 1
  }

  setMensaje1(){
    this.mensaje1 = "Por favor seleccione la hora de entrada o salida."
  }

  setMensaje2(){
    this.mensaje2 = "Seleccione 'entrada' o 'salida'."
  }

  verificarFlags(){
    if((this.form.value.entradaFlag && !this.form.value.salidaFlag) || (!this.form.value.entradaFlag && this.form.value.salidaFlag)){
      return 1
    } else {
      return 0
    }
  }

  verificarHoras(){
    if(this.form.value.entradaFlag && !this.form.value.salidaFlag){
      if(this.form.value.horaInicio != ""){
        return 1
      } else {
        return 0
      }
    } else if (!this.form.value.entradaFlag && this.form.value.salidaFlag){
      if(this.form.value.horaFinal != ""){
        return 1
      } else {
        return 0
      }
    }
    return 0
    
  }

}
