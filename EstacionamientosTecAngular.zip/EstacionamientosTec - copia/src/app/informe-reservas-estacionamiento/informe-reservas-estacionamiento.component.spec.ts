import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InformeReservasEstacionamientoComponent } from './informe-reservas-estacionamiento.component';

describe('InformeReservasEstacionamientoComponent', () => {
  let component: InformeReservasEstacionamientoComponent;
  let fixture: ComponentFixture<InformeReservasEstacionamientoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InformeReservasEstacionamientoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InformeReservasEstacionamientoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
