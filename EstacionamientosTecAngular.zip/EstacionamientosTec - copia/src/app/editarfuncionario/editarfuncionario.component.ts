import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-editarfuncionario',
  templateUrl: './editarfuncionario.component.html',
  styleUrls: ['./editarfuncionario.component.css']
})
export class EditarfuncionarioComponent implements OnInit {
  avisoCorreo: string;
  form: FormGroup;
  departamentos: any;
  jsonDatos: any;

  constructor(private dataservice: DataServiceService) { }

  ngOnInit(): void {
    this.avisoCorreo = '';

    //FALAT PINTAR LA INFO DEFAULT

    this.form = new FormGroup({
      correo: new FormControl(''),
      password: new FormControl(''),
      telefono: new FormControl(''),
      departamento: new FormControl(''),
      identificacion: new FormControl(''),
      placa1: new FormControl(''),
      placa2: new FormControl(''),
      placa3: new FormControl(''),
      placa4: new FormControl(''),
      lunesA: new FormControl(''), lunesB: new FormControl(''),
      martesA: new FormControl(''), martesB: new FormControl(''),
      miercolesA: new FormControl(''), miercolesB: new FormControl(''),
      juevesA: new FormControl(''), juevesB: new FormControl(''),
      viernesA: new FormControl(''), viernesB: new FormControl(''),
      sabadoA: new FormControl(''), sabadoB: new FormControl(''),
      domingoA: new FormControl(''), domingoB: new FormControl(''),
      notificarCorreoAlterno: new FormControl(false),
    });

    const departamentos = this.dataservice.getDepartamentos();
    departamentos.subscribe(res => {
      this.departamentos = res;
    });
    console.log(JSON.parse(this.dataservice.usuarioInfo[0])[0].usuarioId);
    const respuesta = this.dataservice.pintarInformacionPropia(JSON.parse(this.dataservice.usuarioInfo[0])[0].usuarioId);
    respuesta.subscribe(res => {
      console.log('hola');
      this.jsonDatos = res;
      //this.jsonDatos = this.jsonDatos[0];
      console.log(this.jsonDatos);

      let correopintar = JSON.parse(this.jsonDatos[0])[0].correo;
      let telefono = JSON.parse(this.jsonDatos[0])[0].telefono;
      let depart = JSON.parse(this.jsonDatos[0])[0].departamento;
      let notificaciones = JSON.parse(this.jsonDatos[0])[0].notificarCorreoAlterno;

      this.form.get("correo")?.setValue(correopintar);
      this.form.get("telefono")?.setValue(telefono);
      this.form.get("departamento")?.setValue(depart);
      this.form.get("notificarCorreoAlterno")?.setValue(notificaciones);

      let contador = 0;
      for(let placa of (JSON.parse(this.jsonDatos[1]))){
        let placa_aux = JSON.parse(this.jsonDatos[1])[contador].placa;
        if(contador == 0){
          this.form.get("placa1")?.setValue(placa_aux);
        } else if(contador == 1){
          this.form.get("placa2")?.setValue(placa_aux);
        } else if(contador == 2){
          this.form.get("placa3")?.setValue(placa_aux);
        } else if(contador == 3){
          this.form.get("placa4")?.setValue(placa_aux);
        } 
        contador++;
      }

      contador = 0;
      for(let dia of (JSON.parse(this.jsonDatos[2]))){
        let diasemana = JSON.parse(this.jsonDatos[2])[contador].diaSemana;
        let horainicio = JSON.parse(this.jsonDatos[2])[contador].horaInicio;
        let horafinal = JSON.parse(this.jsonDatos[2])[contador].horaFinal;

        if(diasemana == 1){
          this.form.get("lunesA")?.setValue(horainicio);
          this.form.get("lunesB")?.setValue(horafinal);
        } 
        else if(diasemana == 2) {
          this.form.get("martesA")?.setValue(horainicio);
          this.form.get("martesB")?.setValue(horafinal);
        }
        else if(diasemana == 3) {
          this.form.get("miercolesA")?.setValue(horainicio);
          this.form.get("miercolesB")?.setValue(horafinal);
        }
        else if(diasemana == 4) {
          this.form.get("juevesA")?.setValue(horainicio);
          this.form.get("juevesB")?.setValue(horafinal);
        }
        else if(diasemana == 5) {
          this.form.get("viernesA")?.setValue(horainicio);
          this.form.get("viernesB")?.setValue(horafinal);
        }
        else if(diasemana == 6) {
          this.form.get("sabadoA")?.setValue(horainicio);
          this.form.get("sabadoB")?.setValue(horafinal);
        }
        else if(diasemana == 7) {
          this.form.get("domingoA")?.setValue(horainicio);
          this.form.get("domingoB")?.setValue(horafinal);
        }
        contador++;
      }
      
    });


  }

  submit(){
    /*Aquí se envia el JSON al dataservice para ser enviado al API*/
    if(this.verificarCorreo() == 1){
      this.avisoCorreo = '';
      let jsonInputs = this.form.value;
      jsonInputs.usuarioId = JSON.parse(this.jsonDatos[0])[0].usuarioId.toString();


      if(jsonInputs.password === ''){
        delete jsonInputs.password;
      }

      if(jsonInputs.notificarCorreoAlterno == true){
        jsonInputs.notificarCorreoAlterno = "1";
      } else if (jsonInputs.notificarCorreoAlterno == false){
        jsonInputs.notificarCorreoAlterno = "0";
      }

      this.dataservice.modificarInformacionFuncionario(jsonInputs);
    } else if (this.verificarCorreo() == 0) {
      console.log('correo con dominio incorrecto');
      this.avisoCorreo = 'EL CORREO ELECTRÓNICO NO ES DE DOMINIO @itcr.ac.cr'
    }
  }

  verificarCorreo(){
    let correo = this.form.value.correo;
    if(correo.includes('@itcr.ac.cr')){
      return 1;
    } else {
      return 0;
    }
  }

  delete(){
    const id = this.dataservice.index;
    let json = {usuarioId: id};
    this.dataservice.eliminarFuncionario(json);
  }

}
