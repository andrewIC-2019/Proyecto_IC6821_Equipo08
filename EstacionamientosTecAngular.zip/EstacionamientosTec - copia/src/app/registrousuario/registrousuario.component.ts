import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-registrousuario',
  templateUrl: './registrousuario.component.html',
  styleUrls: ['./registrousuario.component.css']
})
export class RegistrousuarioComponent implements OnInit {

  avisoCorreo: string;
  form: FormGroup;
  departamentos: any;
  horarioEjemplo: any;
  diasSemana: any;
  

  constructor(private dataservice: DataServiceService, private router: Router) { }

  ngOnInit(): void {
    this.avisoCorreo = '';

    this.diasSemana = [{dia: "Lunes", id: 1}, {dia: "Martes", id: 2}, {dia: "Miércoles", id: 3}, {dia: "Jueves", id: 4}, {dia: "Viernes", id: 5}, {dia: "Sábado", id: 6}, {dia: "Domingo", id: 7}];

    this.horarioEjemplo = [{
      "diaSemana": 1,
      "horaInicio": "00:00:00",
      "horaFinal": "00:00:00"
    }]; 

    this.form = new FormGroup({
      correoInstitucional: new FormControl('', Validators.required),
      correo: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required),
      telefono: new FormControl('', Validators.required),
      nombre: new FormControl('', Validators.required),
      apellido1: new FormControl('', Validators.required),
      apellido2: new FormControl(''),
      departamento: new FormControl('', Validators.required),
      identificacion: new FormControl('', Validators.required),
      placa1: new FormControl(''),
      placa2: new FormControl(''),
      placa3: new FormControl(''),
      placa4: new FormControl(''),
      esJefatura: new FormControl(false),
      esAdministrador: new FormControl(false),
      esDiscapacitado: new FormControl(false),
      esOperador: new FormControl(false),
      notificacionesBox: new FormControl(false, Validators.required),
    });

    const departamentos = this.dataservice.getDepartamentos();
    departamentos.subscribe(res => {
      this.departamentos = res;
    })
  }

  submit(){
    this.guardarHorarios();
    /*Aquí se envia el JSON al dataservice para ser enviado al API*/
    if(this.verificarCorreo() == 1){
      this.avisoCorreo = '';
      let jsonInputs = this.form.value;
      if(jsonInputs.notificacionesBox == true){
        jsonInputs.notificarCorreoAlterno = "1";
      } else {
        jsonInputs.notificarCorreoAlterno = "0";
      }

      jsonInputs.horarios = this.horarioEjemplo;

      this.dataservice.registrarFuncionario2(jsonInputs);
      this.router.navigateByUrl('inicioadmin');
      
    } else if (this.verificarCorreo() == 0) {
      console.log('correo con dominio incorrecto');
      this.avisoCorreo = 'EL CORREO ELECTRÓNICO NO ES DE DOMINIO @itcr.ac.cr'
    }
  }

  verificarCorreo(){
    let correo = this.form.value.correoInstitucional;
    if(correo.includes('@itcr.ac.cr')){
      return 1;
    } else {
      return 0;
    }
  }

  agregarHorario(){
    // console.log(typeof this.horarioEjemplo);
    // console.log(this.horarioEjemplo);
    // console.log(this.horarioEjemplo);
    // console.log(this.horarioEjemplo[0]);
    // console.log(this.horarioEjemplo.length);
    console.log(this.horarioEjemplo);
    let largo = this.horarioEjemplo.length;

    this.horarioEjemplo[largo] = {
        "diaSemana": 0,
        "horaInicio": "00:00:00",
        "horaFinal": "00:00:00"
      };
  }

  guardarHorarios(){
    var x = document.querySelectorAll("#de");
    console.log(x);

    var contador = 0;

    for(let input of x){

      if(!((input as HTMLInputElement).value)){
        this.horarioEjemplo[contador].horaInicio = (input as HTMLInputElement).placeholder;
      }
      else {
        this.horarioEjemplo[contador].horaInicio = (input as HTMLInputElement).value;
      }

      contador++;
    }


    var y = document.querySelectorAll("#a");
    contador = 0;

    for(let input of y){

      if(!((input as HTMLInputElement).value)){
        this.horarioEjemplo[contador].horaFinal = (input as HTMLInputElement).placeholder;
      }
      else {
        this.horarioEjemplo[contador].horaFinal = (input as HTMLInputElement).value;
      }

      contador++;
    }

    var z = document.querySelectorAll("#dia");
    contador = 0;

    for(let select of z){
      this.horarioEjemplo[contador].diaSemana = (select as HTMLInputElement).value;
      contador++;
    }


    while(contador < 100){
      this.borrarHorariosSobrantes();
      contador++;
    }


    console.log(this.horarioEjemplo);

  }

  borrarHorariosSobrantes(){
    var contador = 0;
    for(let element of this.horarioEjemplo){
      if(element.horaInicio == "00:00:00" && element.horaFinal == "00:00:00"){
        this.horarioEjemplo.splice(contador, 1);
        contador++;
        continue;
      }
      contador++;
    }
  }

}
