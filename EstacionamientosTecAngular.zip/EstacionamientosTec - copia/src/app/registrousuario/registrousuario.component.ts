import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-registrousuario',
  templateUrl: './registrousuario.component.html',
  styleUrls: ['./registrousuario.component.css']
})
export class RegistrousuarioComponent implements OnInit {

  avisoCorreo: string;
  form: FormGroup;
  departamentos: any;

  constructor(private dataservice: DataServiceService) { }

  ngOnInit(): void {
    this.avisoCorreo = '';

    this.form = new FormGroup({
      correoInstitucional: new FormControl('', Validators.required),
      correo: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required),
      telefono: new FormControl('', Validators.required),
      nombre: new FormControl('', Validators.required),
      apellido1: new FormControl('', Validators.required),
      apellido2: new FormControl(''),
      departamento: new FormControl('', Validators.required),
      identificacion: new FormControl('', Validators.required),
      placa1: new FormControl(''),
      placa2: new FormControl(''),
      placa3: new FormControl(''),
      placa4: new FormControl(''),
      lunesA: new FormControl(''), lunesB: new FormControl(''),
      martesA: new FormControl(''), martesB: new FormControl(''),
      miercolesA: new FormControl(''), miercolesB: new FormControl(''),
      juevesA: new FormControl(''), juevesB: new FormControl(''),
      viernesA: new FormControl(''), viernesB: new FormControl(''),
      sabadoA: new FormControl(''), sabadoB: new FormControl(''),
      domingoA: new FormControl(''), domingoB: new FormControl(''),
      notificacionesBox: new FormControl(false, Validators.required),
    });

    const departamentos = this.dataservice.getDepartamentos();
    departamentos.subscribe(res => {
      this.departamentos = res;
    })
  }

  submit(){
    /*Aquí se envia el JSON al dataservice para ser enviado al API*/
    if(this.verificarCorreo() == 1){
      this.avisoCorreo = '';
      let jsonInputs = this.form.value;
      if(jsonInputs.notificacionesBox == true){
        jsonInputs.notificarCorreoAlterno = "1";
      } else {
        jsonInputs.notificarCorreoAlterno = "0";
      }

      this.dataservice.registrarFuncionario(jsonInputs);
      
    } else if (this.verificarCorreo() == 0) {
      console.log('correo con dominio incorrecto');
      this.avisoCorreo = 'EL CORREO ELECTRÓNICO NO ES DE DOMINIO @itcr.ac.cr'
    }
  }

  verificarCorreo(){
    let correo = this.form.value.correoInstitucional;
    if(correo.includes('@itcr.ac.cr')){
      return 1;
    } else {
      return 0;
    }
  }

}
