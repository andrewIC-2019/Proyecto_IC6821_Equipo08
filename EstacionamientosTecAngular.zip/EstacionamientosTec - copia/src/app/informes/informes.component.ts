import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { DataServiceService } from '../data-service.service';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { Router } from '@angular/router';

@Component({
  selector: 'app-informes',
  templateUrl: './informes.component.html',
  styleUrls: ['./informes.component.css']
})
export class InformesComponent implements OnInit {

  identificacion: string;

  constructor(private dataservice:DataServiceService, private router: Router) { }

  ngOnInit(): void {
  }

  funcionarios(){
    this.router.navigateByUrl('inicioadmin/informes/informefuncionarios');
  }

  estacionamientos(){
    this.router.navigateByUrl('inicioadmin/informes/informeestacionamientos');
  }

  horarios(){
    this.router.navigateByUrl('inicioadmin/informes/informehorarios');
  }
  consultaFuncionario(){
    this.dataservice.index = this.identificacion;
    this.router.navigateByUrl('inicioadmin/informes/informefuncionario');
  }

}
