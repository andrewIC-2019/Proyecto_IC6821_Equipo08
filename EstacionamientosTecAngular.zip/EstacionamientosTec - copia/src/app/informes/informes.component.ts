import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { DataServiceService } from '../data-service.service';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { Router } from '@angular/router';

@Component({
  selector: 'app-informes',
  templateUrl: './informes.component.html',
  styleUrls: ['./informes.component.css']
})
export class InformesComponent implements OnInit {

  @ViewChild('informe-funcionarios') htmlData!: ElementRef;

  identificacion: string;

  dataFuncionarios: any;
  dataEstacionamientos: any;
  dataHorarios: any;
  dataFuncionario: any;

  constructor(private dataservice:DataServiceService, private router: Router) { }

  ngOnInit(): void {
  }

  funcionarios(){
    this.router.navigateByUrl('inicioadmin/informes/informefuncionarios');
  }

  estacionamientos(){
    const respuesta = this.dataservice.informeEstacionamientos();
    respuesta.subscribe(res => {
      this.dataEstacionamientos = res;
    });
  }

  horarios(){
    const respuesta = this.dataservice.informeHoras();
    respuesta.subscribe(res => {
      this.dataHorarios = res;
    });
  }
  consultaFuncionario(){
    const respuesta = this.dataservice.informeFuncionario(this.identificacion.toString());
    respuesta.subscribe(res => {
      this.dataFuncionario = res;
    });
  }

}
