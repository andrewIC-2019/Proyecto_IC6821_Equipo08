import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-misreservas',
  templateUrl: './misreservas.component.html',
  styleUrls: ['./misreservas.component.css']
})
export class MisreservasComponent implements OnInit {

  form: FormGroup;
  usuario: any;
  reservaciones: any;

  constructor(private dataservice: DataServiceService) { }

  ngOnInit(): void {

    this.usuario = this.dataservice.usuarioInfo;

    this.form = new FormGroup({
      limiteA: new FormControl(''),
      limiteB: new FormControl(''),
      usuario: new FormControl('')
    });
  }

  submit() {
    let limiteA = this.form.value.limiteA;
    let limiteB = this.form.value.limiteB;
    let usuario = this.dataservice.usuario.usuarioId;
    const respuesta = this.dataservice.verMisReservas(usuario, limiteA, limiteB);

    respuesta.subscribe(res => {
      this.dataservice.misReservaciones = res;
      this.dataservice.misReservaciones = JSON.parse(this.dataservice.misReservaciones[0]);
      this.reservaciones = this.dataservice.misReservaciones;
      for(let item of this.reservaciones){
        if(item.tipoEspacioId === 1){
          item.tipoEspacio = "Particular";
        }else if (item.tipoEspacioId === 2){
          item.tipoEspacio = "Oficial";
        }else if (item.tipoEspacioId === 3){
          item.tipoEspacio = "Visitante";
        }else if (item.tipoEspacioId === 4){
          item.tipoEspacio = "Jefatura";
        }else if (item.tipoEspacioId === 5){
          item.tipoEspacio = "Especial";
        }
      }
      console.log(this.reservaciones);
    } )

  }

}
