import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InformeFuncionarioComponent } from './informe-funcionario.component';

describe('InformeFuncionarioComponent', () => {
  let component: InformeFuncionarioComponent;
  let fixture: ComponentFixture<InformeFuncionarioComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InformeFuncionarioComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InformeFuncionarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
