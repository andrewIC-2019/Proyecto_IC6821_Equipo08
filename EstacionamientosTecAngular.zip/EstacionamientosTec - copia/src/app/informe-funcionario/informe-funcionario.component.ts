import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataServiceService } from '../data-service.service';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

@Component({
  selector: 'app-informe-funcionario',
  templateUrl: './informe-funcionario.component.html',
  styleUrls: ['./informe-funcionario.component.css']
})
export class InformeFuncionarioComponent implements OnInit {

  dataFuncionario: any;
  identificacion: any;

  constructor(private dataservice:DataServiceService, private router: Router) { }

  ngOnInit(): void {
    this.identificacion = this.dataservice.index;
    this.consultaFuncionario()
  }

  consultaFuncionario(){
    const respuesta = this.dataservice.informeFuncionario(this.identificacion.toString());
    respuesta.subscribe(res => {
      this.dataFuncionario = res;
    });
  }

  generateFuncionarioPDF(){
    let DATA: any = document.getElementById('informe-funcionarios');
    html2canvas(DATA).then((canvas) =>{
      let fileWidth = 208;
      let fileHeight = (canvas.height * fileWidth) / canvas.width;

      const FILEURI = canvas.toDataURL('image/png');
      let PDF = new jsPDF('p', 'mm', 'a4');
      let position = 10;
      PDF.addImage(FILEURI, 'PNG', 0, position, fileWidth, fileHeight);
      PDF.save('Reporte_Funcionarios.pdf');
    })
  }

}
