import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InformeHorariosComponent } from './informe-horarios.component';

describe('InformeHorariosComponent', () => {
  let component: InformeHorariosComponent;
  let fixture: ComponentFixture<InformeHorariosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InformeHorariosComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InformeHorariosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
