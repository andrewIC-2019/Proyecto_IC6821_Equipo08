import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import jsPDF from 'jspdf';
import { DataServiceService } from '../data-service.service';
import html2canvas from 'html2canvas';

@Component({
  selector: 'app-informe-ocupacion-departamento-jefe',
  templateUrl: './informe-ocupacion-departamento-jefe.component.html',
  styleUrls: ['./informe-ocupacion-departamento-jefe.component.css']
})
export class InformeOcupacionDepartamentoJefeComponent implements OnInit {
  data: any;

  constructor(private dataservice:DataServiceService, private router: Router) { }

  ngOnInit(): void {
    this.cargar();
  }

  cargar(){
    const respuesta = this.dataservice.informeOcupacionDepartamento(this.dataservice.estacionamientoID.toString());
    respuesta.subscribe(res => {
      console.log(res);
      this.data = res;
      this.dataservice.jsonSinParse = this.data;
      this.data = this.dataservice.jsonSinParse[0];
      this.data = JSON.parse(this.data);
      console.log(this.data)
    });
  }

  generateHorariosPDF(){
    let DATA: any = document.getElementById('informe-funcionarios');
    html2canvas(DATA).then((canvas) =>{
      let fileWidth = 208;
      let fileHeight = (canvas.height * fileWidth) / canvas.width;

      const FILEURI = canvas.toDataURL('image/png');
      let PDF = new jsPDF('p', 'mm', 'a4');
      let position = 10;
      PDF.addImage(FILEURI, 'PNG', 0, position, fileWidth, fileHeight);
      PDF.save('Reporte_Horarios.pdf');
    })
  }



}