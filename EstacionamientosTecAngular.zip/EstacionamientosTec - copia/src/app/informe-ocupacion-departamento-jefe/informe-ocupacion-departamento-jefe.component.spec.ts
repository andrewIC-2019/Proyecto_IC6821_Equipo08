import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InformeOcupacionDepartamentoJefeComponent } from './informe-ocupacion-departamento-jefe.component';

describe('InformeOcupacionDepartamentoJefeComponent', () => {
  let component: InformeOcupacionDepartamentoJefeComponent;
  let fixture: ComponentFixture<InformeOcupacionDepartamentoJefeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InformeOcupacionDepartamentoJefeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InformeOcupacionDepartamentoJefeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
