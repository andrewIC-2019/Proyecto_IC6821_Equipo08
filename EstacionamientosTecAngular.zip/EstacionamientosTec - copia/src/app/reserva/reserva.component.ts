import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-reserva',
  templateUrl: './reserva.component.html',
  styleUrls: ['./reserva.component.css']
})
export class ReservaComponent implements OnInit {

  estacionamientoInfo: any;
  usuario: any;

  avisoCheck: string;
  form: FormGroup;
  mensaje1: any;
  contadorG: any;

  constructor(private dataservice: DataServiceService, private router: Router) { }

  ngOnInit(): void {
    this.contadorG = 0;
    this.usuario = this.dataservice.usuario;
    this.cargaInfo();
    this.avisoCheck = '';

    this.form = new FormGroup({
      fecha: new FormControl('', Validators.required),
      horaInicio: new FormControl(''),
      horaFinal: new FormControl(''),
      periodo: new FormControl(''),
      recurrente: new FormControl(false),
      espacioEspecial: new FormControl(false),
      espacioJefatura: new FormControl(false),
      espacioNormal: new FormControl(false)
    });
  }

  async cargaInfo(){
    const estacionamientoId = this.dataservice.index;
    const respuesta = this.dataservice.infoEstacionamiento(estacionamientoId);
    respuesta.subscribe(res => {
      this.dataservice.estacionamientoInfo = res;
      this.estacionamientoInfo = this.dataservice.estacionamientoInfo;
      console.log(this.estacionamientoInfo);
    });
  }

  submit() {
    if(this.verificarCheck() === 1){
      this.avisoCheck = '';

      if(this.verificarHoras() === 1){
        this.mensaje1 = '';
        this.ajustarFechaHoras();
        let jsonInputs = this.form.value;

        jsonInputs.tipoEspacioId = this.asignarTipoEspacio().toString();
        jsonInputs.usuarioId = this.usuario.usuarioId.toString();
        //console.log(this.dataservice.estacionamientoInfo[0].estacionamientoId.toString());
        jsonInputs.estacionamientoId = this.dataservice.estacionamientoInfo[0].estacionamientoId.toString();

        jsonInputs.entrada = jsonInputs.horaInicio;
        jsonInputs.salida = jsonInputs.horaFinal;
        jsonInputs.dia = jsonInputs.fecha;

        console.log(jsonInputs);
        console.log(jsonInputs.estacionamientoId);

        if(this.form.value.espacioNormal){
          this.dataservice.reservarFuncionario(jsonInputs);
          this.router.navigateByUrl('inicio');

        }else if (this.form.value.espacioJefatura){
          this.dataservice.reservarJefatura(jsonInputs);
          this.router.navigateByUrl('inicio');
        }


      } else {
        this.setMensaje1();
      }
    } else {
      this.avisoCheck = 'Seleccione únicamente un tipo de espacio';
    }
  }

  asignarTipoEspacio(){

    if(this.form.value.espacioJefatura === true){
      return 4
    }else if(this.form.value.espacioNormal === true){
      return 1
    }else if(this.form.value.espacioEspecial === true){
      return 5
    }
    return 0
  }

  ajustarFechaHoras(){
    if(!this.form.value.esJefatura){
      this.form.value.horaInicio = this.form.value.fecha + " " + this.form.value.horaInicio;
      this.form.value.horaFinal = this.form.value.fecha + " " + this.form.value.horaFinal;
    }

  }

  verificarCheck() {
    let especial = this.form.value.espacioEspecial;
    let jefatura = this.form.value.espacioJefatura;
    let normal = this.form.value.espacioNormal;

    let arrayBanderas = [especial, jefatura, normal];
    let contador = 0;

    for(let bandera of arrayBanderas) {
        if(bandera){
          contador++;
        }
    }
    if(contador === 1) {
      return 1;
    } else {
      return 0;
    }
  }

  setMensaje1(){
    this.mensaje1 = "Por favor seleccione las horas."
  }

  verificarHoras(){
    if(!this.dataservice.usuario.esJefatura){
      if(this.form.value.horaInicio != "" && this.form.value.horaFinal != ""){
        return 1
      } else {
        return 0
      }
    }
    return 1
  }

}
