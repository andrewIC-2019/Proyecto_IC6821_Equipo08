import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InformeEstacionamientosComponent } from './informe-estacionamientos.component';

describe('InformeEstacionamientosComponent', () => {
  let component: InformeEstacionamientosComponent;
  let fixture: ComponentFixture<InformeEstacionamientosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InformeEstacionamientosComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InformeEstacionamientosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
