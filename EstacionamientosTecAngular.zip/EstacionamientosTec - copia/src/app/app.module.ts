import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { InicioComponent } from './inicio/inicio.component';
import { Page404Component } from './page404/page404.component';
import { NavbarComponent } from './navbar/navbar.component';
import { EstacionamientoInfoComponent } from './estacionamiento-info/estacionamiento-info.component';
import { ReservaComponent } from './reserva/reserva.component';
import { MisreservasComponent } from './misreservas/misreservas.component';
import { InicioadminComponent } from './inicioadmin/inicioadmin.component';
import { RegistroestacionamientoComponent } from './registroestacionamiento/registroestacionamiento.component';
import { RegistrousuarioComponent } from './registrousuario/registrousuario.component';
import { ModificarinfoComponent } from './modificarinfo/modificarinfo.component';
import { InformesComponent } from './informes/informes.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModificarestacionamientoComponent } from './modificarestacionamiento/modificarestacionamiento.component';
import { EstacionamientosAdminComponent } from './estacionamientos-admin/estacionamientos-admin.component';
import { HttpClient, HttpClientModule, HttpClientXsrfModule } from '@angular/common/http';
import { EditarfuncionarioComponent } from './editarfuncionario/editarfuncionario.component';
import { InformeFuncionariosComponent } from './informe-funcionarios/informe-funcionarios.component';
import { InformeEstacionamientosComponent } from './informe-estacionamientos/informe-estacionamientos.component';
import { InformeHorariosComponent } from './informe-horarios/informe-horarios.component';
import { InformeFuncionarioComponent } from './informe-funcionario/informe-funcionario.component';
import { ReservasOficialesComponent } from './reservas-oficiales/reservas-oficiales.component';
import { ReservasVisitantesComponent } from './reservas-visitantes/reservas-visitantes.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    InicioComponent,
    Page404Component,
    NavbarComponent,
    EstacionamientoInfoComponent,
    ReservaComponent,
    MisreservasComponent,
    InicioadminComponent,
    RegistroestacionamientoComponent,
    RegistrousuarioComponent,
    ModificarinfoComponent,
    InformesComponent,
    ModificarestacionamientoComponent,
    EstacionamientosAdminComponent,
    EditarfuncionarioComponent,
    InformeFuncionariosComponent,
    InformeEstacionamientosComponent,
    InformeHorariosComponent,
    InformeFuncionarioComponent,
    ReservasOficialesComponent,
    ReservasVisitantesComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
