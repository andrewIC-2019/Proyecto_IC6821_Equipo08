import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  inputCorreo: string;
  inputContrasena: string;
  usuario: any;

  constructor(private router: Router, private dataservice: DataServiceService) { }

  ngOnInit(): void {
  }

  login(){
    /*Se escribe la información recogida en formato JSON*/
    let jsonLogin = {
      username: this.inputCorreo,
      password: this.inputContrasena
    }

    const respuesta = this.dataservice.login(jsonLogin.username, jsonLogin.password);
    respuesta.subscribe(res => {
      console.log(res);
      if(Object.keys(res).length !== 0){
        this.usuario = res;
          if(this.usuario[0] != {}){
            this.verificarTipoLogin();
          }
      }
    });
  }

  verificarTipoLogin(){
    /*VERIFICA SI ES USUARIO NORMAL O ADMIN Y REDIRIGE LA PAGINA*/
    this.dataservice.usuario = this.usuario[0];
    if(this.usuario[0].esAdministrador === false){
      this.router.navigateByUrl('/inicio');
    } else if(this.usuario[0].esAdministrador === true) {
      this.router.navigateByUrl('/inicioadmin');
    }
  }


}
