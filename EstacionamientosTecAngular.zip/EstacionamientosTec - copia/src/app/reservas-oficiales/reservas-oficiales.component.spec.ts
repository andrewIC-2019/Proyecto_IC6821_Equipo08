import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReservasOficialesComponent } from './reservas-oficiales.component';

describe('ReservasOficialesComponent', () => {
  let component: ReservasOficialesComponent;
  let fixture: ComponentFixture<ReservasOficialesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReservasOficialesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReservasOficialesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
