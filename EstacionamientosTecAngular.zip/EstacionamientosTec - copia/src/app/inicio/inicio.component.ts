import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.component.html',
  styleUrls: ['./inicio.component.css']
})
export class InicioComponent implements OnInit {

  estacionamientos: any;

  constructor(private router: Router, private dataservice: DataServiceService) { }

  ngOnInit(){
    this.inicio();
    console.log(this.dataservice.usuario);
  }

  async inicio() {
    // const respuesta1 = this.dataservice.inicio();
    
    // if(respuesta1){
    //   respuesta1.subscribe(res => {
    //     this.estacionamientos = res;
    //   });
    // }

    const usuario = this.dataservice.usuario;

    const respuesta = this.dataservice.getEstacionamientosNuevo("1", usuario.usuarioId.toString());
    if(respuesta){
        respuesta.subscribe(res => {

          this.dataservice.estacionamientos = res;
          this.dataservice.estacionamientos = this.dataservice.estacionamientos[0];
          console.log(JSON.parse(this.dataservice.estacionamientos));
          this.estacionamientos = JSON.parse(this.dataservice.estacionamientos);
          console.log(this.estacionamientos)
      });
    }
  }

  click(index: number) {
    const estacionamientoId = this.estacionamientos[index].estacionamientoId.toString();
    console.log(estacionamientoId);
    const respuesta = this.dataservice.infoEstacionamiento(estacionamientoId);
    respuesta.subscribe(res => {
      this.dataservice.estacionamientoInfo = res;
      this.dataservice.estacionamientoInfo = this.dataservice.estacionamientoInfo[0];
      this.dataservice.index = (index+1).toString();
      console.log(this.dataservice.estacionamientoInfo);
      this.router.navigateByUrl('inicio/estacionamientoinfo');
    });
  }

}
