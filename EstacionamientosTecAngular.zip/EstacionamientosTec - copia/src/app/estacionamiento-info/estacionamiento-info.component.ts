import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-estacionamiento-info',
  templateUrl: './estacionamiento-info.component.html',
  styleUrls: ['./estacionamiento-info.component.css']
})
export class EstacionamientoInfoComponent implements OnInit {

  estacionamientoInfo: any;
  usuario: any;


  constructor(private router: Router, private dataservice: DataServiceService) { }

  ngOnInit(): void {
    this.cargaInfo();
    this.usuario = this.dataservice.usuario;
  }

  async cargaInfo(){

    const estacionamientoId = this.dataservice.index;
    const respuesta = this.dataservice.infoEstacionamiento(estacionamientoId);
    respuesta.subscribe(res => {
      this.dataservice.estacionamientoInfo = res;
      this.estacionamientoInfo = this.dataservice.estacionamientoInfo;
      console.log(this.estacionamientoInfo);
    });
  }

  click() {
    this.router.navigateByUrl('inicio/estacionamientoinfo/reserva');
  }

  clickOficiales(){
    this.router.navigateByUrl('inicio/estacionamientoinfo/reservaoficiales');
  }

  clickVisitantes(){
    this.router.navigateByUrl('inicio/estacionamientoinfo/reservavisitantes');
  }

}
