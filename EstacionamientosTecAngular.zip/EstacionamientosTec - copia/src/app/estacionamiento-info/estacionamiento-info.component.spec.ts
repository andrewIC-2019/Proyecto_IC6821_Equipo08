import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EstacionamientoInfoComponent } from './estacionamiento-info.component';

describe('EstacionamientoInfoComponent', () => {
  let component: EstacionamientoInfoComponent;
  let fixture: ComponentFixture<EstacionamientoInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EstacionamientoInfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EstacionamientoInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
