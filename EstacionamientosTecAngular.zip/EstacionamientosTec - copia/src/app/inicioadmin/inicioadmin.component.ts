import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-inicioadmin',
  templateUrl: './inicioadmin.component.html',
  styleUrls: ['./inicioadmin.component.css']
})
export class InicioadminComponent implements OnInit {

  identificacion: string;
  avisoIdentificacion: string;

  constructor(private router: Router, private dataservice: DataServiceService) { }

  ngOnInit(): void {
  }

  clickInstitucionales(){
    this.dataservice.adminMenuFlag = "0";
    this.router.navigateByUrl('inicioadmin/estacionamientos');
  }

  clickSubcontratado(){
    this.dataservice.adminMenuFlag = "1";
    this.router.navigateByUrl('inicioadmin/estacionamientos');
  }

  editarFuncionario(){
    this.dataservice.index = this.identificacion.toString();
    console.log(this.dataservice.pintarInformacionPropia(this.dataservice.index));

    this.dataservice.pintarInformacionPropia(this.dataservice.index).subscribe(res => {
      console.log('entró');
      if(res != '{}'){
        this.avisoIdentificacion = '';
        this.dataservice.usuarioInfo = res;
        if(this.dataservice.usuarioInfo[0] != ''){
          this.router.navigateByUrl('inicioadmin/editarfuncionario');
        }
        /*AQUI VA EL NAVIGATEURL HACIA editarFuncionario*/
      } else {
        this.avisoIdentificacion = 'Digite un número de identificación válido'
      }
    });
    
    //this.router.navigateByUrl('inicioadmin/editarfuncionario');
  }
  
  reservar(){
    this.router.navigateByUrl('inicio');
  }
}
