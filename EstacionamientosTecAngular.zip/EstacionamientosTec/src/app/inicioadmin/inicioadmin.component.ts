import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inicioadmin',
  templateUrl: './inicioadmin.component.html',
  styleUrls: ['./inicioadmin.component.css']
})
export class InicioadminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
