import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-inicioadmin',
  templateUrl: './inicioadmin.component.html',
  styleUrls: ['./inicioadmin.component.css']
})
export class InicioadminComponent implements OnInit {

  identificacion: string;

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  click(){
    this.router.navigateByUrl('inicioadmin/estacionamientos');
  }

  editarFuncionario(){
    
  }

}
