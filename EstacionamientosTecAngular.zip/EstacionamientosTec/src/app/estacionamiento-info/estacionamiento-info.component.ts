import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-estacionamiento-info',
  templateUrl: './estacionamiento-info.component.html',
  styleUrls: ['./estacionamiento-info.component.css']
})
export class EstacionamientoInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
