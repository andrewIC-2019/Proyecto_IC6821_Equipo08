import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-registroestacionamiento',
  templateUrl: './registroestacionamiento.component.html',
  styleUrls: ['./registroestacionamiento.component.css']
})
export class RegistroestacionamientoComponent implements OnInit {

  avisoCheck: string;
  form: FormGroup;

  constructor(private dataservice: DataServiceService) { }

  ngOnInit(): void {
    this.avisoCheck = '';
    this.form = new FormGroup({
      nombre: new FormControl('', Validators.required),
      correo: new FormControl('', Validators.required),
      telefono: new FormControl('', Validators.required),
      direccion: new FormControl('', Validators.required),
      formaAcceso: new FormControl('', Validators.required),
      descripcion: new FormControl('', Validators.required),
      identificacion: new FormControl('', Validators.required),
      cantEspaciosEspeciales: new FormControl(0, Validators.required),
      cantEspaciosJefaturas: new FormControl(0, Validators.required),
      cantEspaciosVisitantes: new FormControl(0, Validators.required),
      cantEspacios: new FormControl(0, Validators.required),
      cantEspaciosOficiales: new FormControl(0, Validators.required),
      imageUrl: new FormControl('', Validators.required),
      horario: new FormGroup({
        lunes: new FormGroup({horaInicio: new FormControl('', Validators.required), horaFinal: new FormControl('', Validators.required)}),
        martes: new FormGroup({horaInicio: new FormControl('', Validators.required), horaFinal: new FormControl('', Validators.required)}),
        miercoles: new FormGroup({horaInicio: new FormControl('', Validators.required), horaFinal: new FormControl('', Validators.required)}),
        jueves: new FormGroup({horaInicio: new FormControl('', Validators.required), horaFinal: new FormControl('', Validators.required)}),
        viernes: new FormGroup({horaInicio: new FormControl('', Validators.required), horaFinal: new FormControl('',Validators.required)}),
        sabado: new FormGroup({horaInicio: new FormControl('', Validators.required), horaFinal: new FormControl('', Validators.required)}),
        domingo: new FormGroup({horaInicio: new FormControl('', Validators.required), horaFinal: new FormControl('', Validators.required)})
      }),
      tipoEstacionamiento: new FormControl('', Validators.required)
    });
  }

  submit(){
    /*Aquí se envia el JSON al dataservice para ser enviado al API*/
      let jsonInputs = this.form.value;
      this.dataservice.registrarEstacionamiento(jsonInputs); //no está insertando nada en la DB
  }

  verificarCheckbox() {
    if((this.form.value.estacionamientoInstitucionalBox === false && this.form.value.estacionamientoSubcontratadoBox === false) 
    || (this.form.value.estacionamientoInstitucionalBox === true && this.form.value.estacionamientoSubcontratadoBox === true)){
      this.avisoCheck = 'Marque solo una de las casillas'
      return 0;
    } else {
      this.avisoCheck = '';
      return 1;
    }
  }

}
