import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registroestacionamiento',
  templateUrl: './registroestacionamiento.component.html',
  styleUrls: ['./registroestacionamiento.component.css']
})
export class RegistroestacionamientoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
