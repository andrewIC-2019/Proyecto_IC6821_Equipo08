import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-reserva',
  templateUrl: './reserva.component.html',
  styleUrls: ['./reserva.component.css']
})
export class ReservaComponent implements OnInit {

  avisoCheck: string;
  form: FormGroup;

  constructor() { }

  ngOnInit(): void {
    this.avisoCheck = '';

    this.form = new FormGroup({
      fecha: new FormControl('', Validators.required),
      horaInicio: new FormControl('', Validators.required),
      horaFinal: new FormControl('', Validators.required),
      periodo: new FormControl('', Validators.required),
      recurrente: new FormControl(false, Validators.required),
      espacioEspecial: new FormControl(false, Validators.required),
      espacioJefatura: new FormControl(false, Validators.required),
      espacioVisitante: new FormControl(false, Validators.required),
      espacioOficial: new FormControl(false, Validators.required),
      espacioNormal: new FormControl(false, Validators.required)
    });
  }

  submit() {
    if(this.verificarCheck() === 1){
      this.avisoCheck = '';
      let jsonInputs = this.form.value;
      console.log(jsonInputs);
    } else {
      this.avisoCheck = 'Seleccione únicamente un tipo de espacio';
    }
  }

  verificarCheck() {
    let especial = this.form.value.espacioEspecial;
    let jefatura = this.form.value.espacioJefatura;
    let visitante = this.form.value.espacioVisitante;
    let oficial = this.form.value.espacioOficial;
    let normal = this.form.value.espacioNormal;

    let arrayBanderas = [especial, jefatura, visitante, oficial, normal];
    let contador = 0;

    for(let bandera of arrayBanderas) {
        if(bandera){
          contador++;
        }
    }
    if(contador === 1) {
      return 1;
    } else {
      return 0;
    }
  }

}
