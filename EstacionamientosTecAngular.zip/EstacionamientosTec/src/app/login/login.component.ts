import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  inputCorreo: string;
  inputContrasena: string;

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  login(){
    
    /*Se escribe la información recogida en formato JSON*/
    let jsonLogin = {
      correo: this.inputCorreo,
      contrasena: this.inputContrasena
    }

    let permiso;
    permiso = 1;

    if(permiso === 1){
      this.router.navigateByUrl('/inicio');
    } else if(permiso === 0) {
      this.router.navigateByUrl('/inicioadmin');
    }

    /*Se envía el JSON al DataService para que luego se envíe al API*/

  }

}
