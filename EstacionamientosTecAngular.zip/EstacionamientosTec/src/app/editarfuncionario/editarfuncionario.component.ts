import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-editarfuncionario',
  templateUrl: './editarfuncionario.component.html',
  styleUrls: ['./editarfuncionario.component.css']
})
export class EditarfuncionarioComponent implements OnInit {

  avisoCheck: string;
  form: FormGroup;

  constructor() { }

  ngOnInit(): void {
    this.avisoCheck = '';
    this.form = new FormGroup({
      nombre: new FormControl('', Validators.required),
      correo: new FormControl('', Validators.required),
      telefono: new FormControl('', Validators.required),
      direccion: new FormControl('', Validators.required),
      acceso: new FormControl('', Validators.required),
      caracteristicas: new FormControl('', Validators.required),
      identificacion: new FormControl('', Validators.required),
      espaciosEspeciales: new FormControl(0, Validators.required),
      espaciosJefatura: new FormControl(0, Validators.required),
      espaciosVisitante: new FormControl(0, Validators.required),
      espaciosNormales: new FormControl(0, Validators.required),
      espaciosOficiales: new FormControl(0, Validators.required),
      imagen: new FormControl('', Validators.required),
      horario: new FormGroup({
        lunes: new FormGroup({horaInicio: new FormControl('', Validators.required), horaFinal: new FormControl('', Validators.required)}),
        martes: new FormGroup({horaInicio: new FormControl('', Validators.required), horaFinal: new FormControl('', Validators.required)}),
        miercoles: new FormGroup({horaInicio: new FormControl('', Validators.required), horaFinal: new FormControl('', Validators.required)}),
        jueves: new FormGroup({horaInicio: new FormControl('', Validators.required), horaFinal: new FormControl('', Validators.required)}),
        viernes: new FormGroup({horaInicio: new FormControl('', Validators.required), horaFinal: new FormControl('',Validators.required)}),
        sabado: new FormGroup({horaInicio: new FormControl('', Validators.required), horaFinal: new FormControl('', Validators.required)}),
        domingo: new FormGroup({horaInicio: new FormControl('', Validators.required), horaFinal: new FormControl('', Validators.required)})
      }),
      estacionamientoInstitucionalBox: new FormControl(false, Validators.required),
      estacionamientoSubcontratadoBox: new FormControl(false, Validators.required)
    });
  }

  submit(){
    /*Aquí se envia el JSON al dataservice para ser enviado al API*/
    if(this.verificarCheckbox() === 1){
      let jsonInputs = this.form.value;
      console.log(jsonInputs);
    }
  }

  verificarCheckbox() {
    if((this.form.value.estacionamientoInstitucionalBox === false && this.form.value.estacionamientoSubcontratadoBox === false) 
    || (this.form.value.estacionamientoInstitucionalBox === true && this.form.value.estacionamientoSubcontratadoBox === true)){
      this.avisoCheck = 'Marque solo una de las casillas'
      return 0;
    } else {
      this.avisoCheck = '';
      return 1;
    }
  }

}
