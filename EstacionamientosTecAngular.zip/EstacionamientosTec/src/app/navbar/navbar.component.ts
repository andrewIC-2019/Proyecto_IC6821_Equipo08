import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  admin: any;
  usuario: any;
  constructor(private router: Router, private dataservice: DataServiceService) { }

  ngOnInit(): void {
    this.admin = null;
    if(this.dataservice.Usuario.esAdministrador === true){
      this.admin = this.dataservice.Usuario.esAdministrador;
    };
  }

  click() {
    this.router.navigateByUrl('inicio/miinformacion');
  }

  informes() {
    this.router.navigateByUrl('inicioadmin/informes');
  }

  registrarFuncionario() {
    this.router.navigateByUrl('inicioadmin/registrousuario');
  }
  
  registrarEstacionamiento() {
    this.router.navigateByUrl('inicioadmin/registroestacionamiento');
  }

}
