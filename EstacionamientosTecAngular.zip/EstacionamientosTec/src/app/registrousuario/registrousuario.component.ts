import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-registrousuario',
  templateUrl: './registrousuario.component.html',
  styleUrls: ['./registrousuario.component.css']
})
export class RegistrousuarioComponent implements OnInit {

  avisoCorreo: string;
  form: FormGroup;

  constructor() { }

  ngOnInit(): void {
    this.avisoCorreo = '';

    this.form = new FormGroup({
      correoTec: new FormControl('', Validators.required),
      correoAlterno: new FormControl('', Validators.required),
      contrasena: new FormControl('', Validators.required),
      celular: new FormControl('', Validators.required),
      nombre: new FormControl('', Validators.required),
      primerApellido: new FormControl('', Validators.required),
      segundoApellido: new FormControl(''),
      departamento: new FormControl('', Validators.required),
      identificacion: new FormControl('', Validators.required),
      placas: new FormGroup({
        placa1: new FormControl('', Validators.required),
        placa2: new FormControl('', Validators.required),
        placa3: new FormControl('', Validators.required),
        placa4: new FormControl('', Validators.required)
      }),
      horario: new FormGroup({
        lunes: new FormGroup({horaInicio: new FormControl('', Validators.required), horaFinal: new FormControl('', Validators.required)}),
        martes: new FormGroup({horaInicio: new FormControl('', Validators.required), horaFinal: new FormControl('', Validators.required)}),
        miercoles: new FormGroup({horaInicio: new FormControl('', Validators.required), horaFinal: new FormControl('', Validators.required)}),
        jueves: new FormGroup({horaInicio: new FormControl('', Validators.required), horaFinal: new FormControl('', Validators.required)}),
        viernes: new FormGroup({horaInicio: new FormControl('', Validators.required), horaFinal: new FormControl('',Validators.required)}),
        sabado: new FormGroup({horaInicio: new FormControl('', Validators.required), horaFinal: new FormControl('', Validators.required)}),
        domingo: new FormGroup({horaInicio: new FormControl('', Validators.required), horaFinal: new FormControl('', Validators.required)})
      }),
      notificacionesBox: new FormControl(false, Validators.required),
    });
  }

  submit(){
    /*Aquí se envia el JSON al dataservice para ser enviado al API*/
    if(this.verificarCorreo() == 1){
      this.avisoCorreo = '';
      let jsonInputs = this.form.value;
      console.log(jsonInputs);
    } else if (this.verificarCorreo() == 0) {
      console.log('correo con dominio incorrecto');
      this.avisoCorreo = 'EL CORREO ELECTRÓNICO NO ES DE DOMINIO @itcr.ac.cr'
    }
  }

  verificarCorreo(){
    let correo = this.form.value.correoTec;
    if(correo.includes('@itcr.ac.cr')){
      return 1;
    } else {
      return 0;
    }
  }

}
