import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registrousuario',
  templateUrl: './registrousuario.component.html',
  styleUrls: ['./registrousuario.component.css']
})
export class RegistrousuarioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
