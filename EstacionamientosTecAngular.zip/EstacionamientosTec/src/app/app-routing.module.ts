import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EditarfuncionarioComponent } from './editarfuncionario/editarfuncionario.component';
import { EstacionamientoInfoComponent } from './estacionamiento-info/estacionamiento-info.component';
import { EstacionamientosAdminComponent } from './estacionamientos-admin/estacionamientos-admin.component';
import { InformesComponent } from './informes/informes.component';
import { InicioComponent } from './inicio/inicio.component';
import { InicioadminComponent } from './inicioadmin/inicioadmin.component';
import { LoginComponent } from './login/login.component';
import { MisreservasComponent } from './misreservas/misreservas.component';
import { ModificarestacionamientoComponent } from './modificarestacionamiento/modificarestacionamiento.component';
import { ModificarinfoComponent } from './modificarinfo/modificarinfo.component';
import { Page404Component } from './page404/page404.component';
import { RegistroestacionamientoComponent } from './registroestacionamiento/registroestacionamiento.component';
import { RegistrousuarioComponent } from './registrousuario/registrousuario.component';
import { ReservaComponent } from './reserva/reserva.component';

const routes: Routes = [
  {path: '', component: LoginComponent},
  {path: 'inicio', component: InicioComponent},
  {path: 'inicio/estacionamientoinfo', component: EstacionamientoInfoComponent},
  {path: 'inicio/estacionamientoinfo/reserva', component: ReservaComponent},
  {path: 'inicio/misreservas', component: MisreservasComponent},
  {path: 'inicio/miinformacion', component: ModificarinfoComponent},
  {path: 'inicioadmin', component: InicioadminComponent},
  {path: 'inicioadmin/editarfuncionario', component: EditarfuncionarioComponent},
  {path: 'inicioadmin/registroestacionamiento', component: RegistroestacionamientoComponent},
  {path: 'inicioadmin/registrousuario', component: RegistrousuarioComponent},
  {path: 'inicioadmin/estacionamientos', component: EstacionamientosAdminComponent},
  {path: 'inicioadmin/estacionamientos/modificarestacionamiento', component: ModificarestacionamientoComponent},
  {path: 'inicioadmin/informes', component: InformesComponent},
  {path: '**', component: Page404Component}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
