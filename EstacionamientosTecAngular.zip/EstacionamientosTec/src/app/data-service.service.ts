import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class DataServiceService {

  connection: any;
  Usuario: any;
  EstacionamientoInfo: any;



  constructor(private http: HttpClient) {

    this.connection = {
      url: 'http://localhost:5000/api/'
    }

   }


  login(json: Object){
    const jsonRespuesta = this.http.get(`${this.connection.url}/user/login`, json);
    return jsonRespuesta;
  }

  inicio(){
    const jsonRespuesta = this.http.get(`${this.connection.url}/estacionamiento/inicio`);
    return jsonRespuesta;
  }

  infoEstacionamiento(){

  }

  infoUsuario(json: Object){

  }

  reservar(json: Object){

  }

  registrarFuncionario(json: Object){

  }

  modificarInformacionPropia(json: Object){

  }

  modificarInformacionFuncionario(json: Object){

  }

  registrarEstacionaimento(json: Object){

  }

  eliminarEstacionamiento(json: Object){

  }

  eliminarReserva(json: Object){

  }

  informeEstacionamientos(){

  }

  informeFuncionarios(){

  }

  informeHoras(){

  }

  informeFuncionario(json: Object){

  }
}
