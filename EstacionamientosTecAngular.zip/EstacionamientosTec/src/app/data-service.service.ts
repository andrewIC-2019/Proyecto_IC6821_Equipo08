import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class DataServiceService {

  connection: any;
  Usuario: any;
  estacionamientoInfo: any;
  index: string;



  constructor(private http: HttpClient) {

    this.connection = {
      url: 'http://localhost:5000/api/'
    }

   }


  login(json: Object){
    const jsonRespuesta = this.http.get(`${this.connection.url}/user/login`, json);
    return jsonRespuesta;
  }

  inicio(){
    const jsonRespuesta = this.http.get(`${this.connection.url}/estacionamiento/inicio`);
    return jsonRespuesta;
  }

  infoEstacionamiento(id: string){
    const params = new HttpParams().append('estacionamientoId', id);
    const jsonRespuesta = this.http.get(`${this.connection.url}/estacionamiento/estacionamientoinfo`, {params});
    return jsonRespuesta;
  }

  infoUsuario(json: Object){

  }

  reservar(json: Object){

  }

  registrarFuncionario(json: Object){

  }

  pintarInformacionPropia(){  /*****************OJO****************/
    const jsonRespuesta = this.http.get(`${this.connection.url}/user/pintarEditarUsuario`);
    return jsonRespuesta;
  }

  modificarInformacionPropia(json: Object){

  }

  modificarInformacionFuncionario(json: Object){

  }

  registrarEstacionamiento(json: Object){ /*****************OJO****************/
  console.log(json);
    const jsonRespuesta = this.http.post(`${this.connection.url}/estacionamiento/registrarEstacionamiento`, json);
    return jsonRespuesta;
  }

  eliminarEstacionamiento(json: Object){

  }

  eliminarReserva(json: Object){

  }

  informeEstacionamientos(){

  }

  informeFuncionarios(){

  }

  informeHoras(){

  }

  informeFuncionario(json: Object){

  }
}
