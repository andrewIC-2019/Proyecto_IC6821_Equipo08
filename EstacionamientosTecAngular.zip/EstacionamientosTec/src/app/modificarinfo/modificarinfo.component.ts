import { Component, OnInit } from '@angular/core';
import { ControlContainer, FormControl, FormGroup, Validators } from '@angular/forms';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-modificarinfo',
  templateUrl: './modificarinfo.component.html',
  styleUrls: ['./modificarinfo.component.css']
})
export class ModificarinfoComponent implements OnInit {

  form: FormGroup;
  jsonDatos: any;

  constructor(private dataservice: DataServiceService) { }

  ngOnInit(): void {

    const respuesta = this.dataservice.pintarInformacionPropia(); //falta pinta (tira error)
    respuesta.subscribe(res => {
      this.jsonDatos = res;
      this.jsonDatos = this.jsonDatos[0];
      console.log(this.jsonDatos);

      this.form = new FormGroup({
        correoAlterno: new FormControl(''),
        contrasena: new FormControl(''),
        celular: new FormControl(''),
        departamento: new FormControl(''),
        placas: new FormGroup({
          placa1: new FormControl(''),
          placa2: new FormControl(''),
          placa3: new FormControl(''),
          placa4: new FormControl('')
        }),
        horario: new FormGroup({
          lunes: new FormGroup({horaInicio: new FormControl(''), horaFinal: new FormControl('')}),
          martes: new FormGroup({horaInicio: new FormControl(''), horaFinal: new FormControl('')}),
          miercoles: new FormGroup({horaInicio: new FormControl(''), horaFinal: new FormControl('')}),
          jueves: new FormGroup({horaInicio: new FormControl(''), horaFinal: new FormControl('')}),
          viernes: new FormGroup({horaInicio: new FormControl(''), horaFinal: new FormControl('')}),
          sabado: new FormGroup({horaInicio: new FormControl(''), horaFinal: new FormControl('')}),
          domingo: new FormGroup({horaInicio: new FormControl(''), horaFinal: new FormControl('')})
        }),
        notificacionesBox: new FormControl(false, Validators.required),
      });

    });

  }

  submit() {

    /*Aquí se mandan los datos en JSON al dataservice para mandarlo al API*/
    let jsonInputs = this.form.value;
    console.log(jsonInputs);
  }

}
