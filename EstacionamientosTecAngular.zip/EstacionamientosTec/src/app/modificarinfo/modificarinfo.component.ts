import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modificarinfo',
  templateUrl: './modificarinfo.component.html',
  styleUrls: ['./modificarinfo.component.css']
})
export class ModificarinfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
