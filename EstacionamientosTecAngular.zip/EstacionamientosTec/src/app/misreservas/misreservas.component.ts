import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-misreservas',
  templateUrl: './misreservas.component.html',
  styleUrls: ['./misreservas.component.css']
})
export class MisreservasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
