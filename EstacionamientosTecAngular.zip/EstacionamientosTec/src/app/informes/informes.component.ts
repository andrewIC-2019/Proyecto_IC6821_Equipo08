import { Component, OnInit } from '@angular/core';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-informes',
  templateUrl: './informes.component.html',
  styleUrls: ['./informes.component.css']
})
export class InformesComponent implements OnInit {

  identificacion: string;

  constructor(private dataservice:DataServiceService) { }

  ngOnInit(): void {
  }

  funcionarios(){
    this.dataservice.informeFuncionarios();
  }

  estacionamientos(){
    this.dataservice.informeEstacionamientos();
  }

  horarios(){
    this.dataservice.informeHoras();
  }
  consultaFuncionario(){
    this.dataservice.informeFuncionario(this.identificacion.toString());
  }

}
