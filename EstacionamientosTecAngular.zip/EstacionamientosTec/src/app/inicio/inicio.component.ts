import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.component.html',
  styleUrls: ['./inicio.component.css']
})
export class InicioComponent implements OnInit {

  estacionamientos: any;

  constructor(private router: Router, private dataservice: DataServiceService) { }

  ngOnInit(){
    this.inicio();
  }

  async inicio() {
    const respuesta = this.dataservice.inicio();
    if(respuesta){
      respuesta.subscribe(res => {
        this.estacionamientos = res;
        console.log(this.estacionamientos)
      });
    }
  }

  click(index: number) {
    const estacionamientoId = this.estacionamientos[index].estacionamientoId.toString();
    console.log(estacionamientoId);
    const respuesta = this.dataservice.infoEstacionamiento(estacionamientoId);
    respuesta.subscribe(res => {
      this.dataservice.estacionamientoInfo = res;
      this.dataservice.estacionamientoInfo = this.dataservice.estacionamientoInfo[0];
      this.dataservice.index = (index+1).toString();
      console.log(this.dataservice.estacionamientoInfo);
      this.router.navigateByUrl('inicio/estacionamientoinfo');
    });
  }

}
