import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.component.html',
  styleUrls: ['./inicio.component.css']
})
export class InicioComponent implements OnInit {

  estacionamientos: any;

  constructor(private router: Router, private dataservice: DataServiceService) { }

  ngOnInit(){
    this.inicio();
  }

  async inicio() {
    const respuesta = this.dataservice.inicio();
    if(respuesta){
      respuesta.subscribe(res => {
        this.estacionamientos = res;
        console.log(this.estacionamientos)
      });
    }
  }

  click() {
    this.router.navigateByUrl('inicio/estacionamientoinfo');
  }

}
